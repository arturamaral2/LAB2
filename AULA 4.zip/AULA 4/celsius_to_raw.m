function u = celsius_to_raw(celsius)
    u = celsius+ ;
end