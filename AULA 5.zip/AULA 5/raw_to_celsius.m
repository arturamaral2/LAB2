function u = raw_to_celsius(raw)
    u = ((5.5/1270)*(raw-40873))+29;
end

