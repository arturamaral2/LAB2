function u = celsius_to_raw(celsius)
    u = round(230.9*(celsius-29)+40873);
end